// server.mjs - example server from the lab guide (stops before routing)
import fs from 'fs';
import http from 'http';
import https from 'https';
import path from 'path';
import express from 'express';
import dotenv from 'dotenv';
import { connectToDb } from './db/connection.mjs';
import { fileURLToPath } from 'url';

dotenv.config();

const app = express();

app.get('/', (req, res) => {
  res.json({
    status: 'ok',
    message: 'INSY7314 Backend up',
    time: new Date().toISOString()
  });
});

const PORT = process.env.PORT || 3000;

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const keyPath = path.join(__dirname, 'keys', 'privatekey.pem');
const certPath = path.join(__dirname, 'keys', 'certificate.pem');

let server;
if (fs.existsSync(keyPath) && fs.existsSync(certPath)) {
  const options = {
    key: fs.readFileSync(keyPath),
    cert: fs.readFileSync(certPath)
  };
  server = https.createServer(options, app);
  console.log('Starting HTTPS server with provided certificates');
} else {
  server = http.createServer(app);
  console.log('Certificates not found. Starting HTTP server');
}

(async () => {
  try {
    await connectToDb(); // tries to connect if MONGODB_URI present
  } catch (err) {
    console.error('MongoDB connection failed:', err?.message || err);
  } finally {
    server.listen(PORT, () => {
      const proto = server instanceof https.Server ? 'https' : 'http';
      console.log(`Server listening at ${proto}://localhost:${PORT}`);
    });
  }
})();
