import { MongoClient } from 'mongodb';
import dotenv from 'dotenv';
dotenv.config();

const uri = process.env.MONGODB_URI;
let client;

export async function connectToDb() {
  if (!uri) {
    console.warn('mongodb://studentUser:MyP@ssw0rd!@cluster0-shard-00-00.abcdz.mongodb.net:27017,cluster0-shard-00-01.abcdz.mongodb.net:27017/myDatabase?ssl=true&replicaSet=atlas-xyz-shard-0&authSource=admin&retryWrites=true&w=majority
');
    return null;
  }
  if (client) return client;
  client = new MongoClient(uri, {
    connectTimeoutMS: 10000,
    serverSelectionTimeoutMS: 10000
  });
  await client.connect();
  console.log('Connected to MongoDB');
  return client;
}

export function getDbClient() {
  return client;
}
