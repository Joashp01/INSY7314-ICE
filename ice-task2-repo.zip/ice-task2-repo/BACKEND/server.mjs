import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import { connectToDb } from './db/connection.mjs';
import postRoutes from './routes/post.mjs';
import userRoutes from './routes/user.mjs';

dotenv.config();
const app = express();
app.use(cors({ origin: '*' }));
app.use(express.json());

app.use('/posts', postRoutes);
app.use('/users', userRoutes);

const PORT = process.env.PORT || 3000;

(async () => {
  await connectToDb();
  app.listen(PORT, () => console.log(`Server running on http://localhost:${PORT}`));
})();
