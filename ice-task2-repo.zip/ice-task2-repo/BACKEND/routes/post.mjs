import express from 'express';
import { ObjectId } from 'mongodb';
import { getDbClient } from '../db/connection.mjs';
import checkAuth from '../middleware/checkAuth.mjs';

const router = express.Router();

router.get('/', async (req, res) => {
  const db = getDbClient().db('myDatabase');
  const posts = await db.collection('posts').find().toArray();
  res.json(posts);
});

router.post('/upload', checkAuth, async (req, res) => {
  const { username, content, picture } = req.body;
  const db = getDbClient().db('myDatabase');
  const result = await db.collection('posts').insertOne({ username, content, picture });
  res.json({ insertedId: result.insertedId });
});

router.patch('/:id', checkAuth, async (req, res) => {
  const { content } = req.body;
  const db = getDbClient().db('myDatabase');
  await db.collection('posts').updateOne(
    { _id: new ObjectId(req.params.id) },
    { $set: { content } }
  );
  res.json({ status: 'updated' });
});

router.delete('/:id', checkAuth, async (req, res) => {
  const db = getDbClient().db('myDatabase');
  await db.collection('posts').deleteOne({ _id: new ObjectId(req.params.id) });
  res.json({ status: 'deleted' });
});

export default router;
