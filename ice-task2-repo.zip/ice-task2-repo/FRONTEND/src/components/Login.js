import { useState } from 'react';

const API = 'http://localhost:3000';

export default function Login() {
  const [username, setU] = useState('');
  const [password, setP] = useState('');
  const [msg, setMsg] = useState('');

  async function submit(e) {
    e.preventDefault();
    try {
      const res = await fetch(`${API}/users/login`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username, password })
      });
      const data = await res.json();
      if (!res.ok || !data.token) throw new Error(data.error || `HTTP ${res.status}`);
      localStorage.setItem('token', data.token);
      setMsg('Logged in. Token stored.');
    } catch (e) {
      setMsg(`Login failed: ${e.message}`);
    }
  }

  return (
    <form onSubmit={submit}>
      <h2>Login</h2>
      <div><input placeholder="username" value={username} onChange={e=>setU(e.target.value)} required /></div>
      <div><input type="password" placeholder="password" value={password} onChange={e=>setP(e.target.value)} required /></div>
      <button type="submit">Login</button>
      <div style={{ marginTop: 8 }}>{msg}</div>
    </form>
  );
}
