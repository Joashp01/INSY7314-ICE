import { useState } from 'react';

const API = 'http://localhost:3000';

export default function PostCreate() {
  const [username, setUsername] = useState('');
  const [content, setContent] = useState('');
  const [picture, setPicture] = useState('');
  const [msg, setMsg] = useState('');

  async function submit(e) {
    e.preventDefault();
    const token = localStorage.getItem('token') || '';
    try {
      const res = await fetch(`${API}/posts/upload`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
        body: JSON.stringify({ username, content, picture })
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || `HTTP ${res.status}`);
      setMsg(`Created with id: ${data.insertedId}`);
      setUsername(''); setContent(''); setPicture('');
    } catch (e) {
      setMsg(`Error: ${e.message}`);
    }
  }

  return (
    <form onSubmit={submit}>
      <h2>Create Post</h2>
      <div><input placeholder="username" value={username} onChange={e=>setUsername(e.target.value)} required /></div>
      <div><input placeholder="content" value={content} onChange={e=>setContent(e.target.value)} required /></div>
      <div><input placeholder="picture (string or data URI)" value={picture} onChange={e=>setPicture(e.target.value)} /></div>
      <button type="submit">Create</button>
      <div style={{ marginTop: 8 }}>{msg}</div>
    </form>
  );
}
