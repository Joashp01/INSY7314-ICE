import { useEffect, useState } from 'react';

const API = 'http://localhost:3000';

export default function PostList() {
  const [rows, setRows] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  async function load() {
    try {
      setLoading(true);
      const res = await fetch(`${API}/posts`);
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const data = await res.json();
      setRows(data);
      setError('');
    } catch (e) {
      setError(e.message || 'Failed to load');
    } finally {
      setLoading(false);
    }
  }

  async function del(id) {
    const token = localStorage.getItem('token') || '';
    try {
      const res = await fetch(`${API}/posts/${id}`, {
        method: 'DELETE',
        headers: { Authorization: `Bearer ${token}` }
      });
      if (!res.ok) {
        const body = await res.json().catch(() => ({}));
        throw new Error(body.error || `HTTP ${res.status}`);
      }
      await load();
    } catch (e) {
      alert(`Delete failed: ${e.message}`);
    }
  }

  useEffect(() => { load(); }, []);

  if (loading) return <div>Loading posts...</div>;
  if (error) return <div style={{ color: 'crimson' }}>Error: {error}</div>;

  return (
    <div>
      <h2>Posts</h2>
      {rows.length === 0 ? <p>No posts yet.</p> : (
        <table border="1" cellPadding="6">
          <thead><tr><th>User</th><th>Content</th><th>Picture</th><th>Actions</th></tr></thead>
          <tbody>
            {rows.map(p => (
              <tr key={p._id}>
                <td>{p.username}</td>
                <td>{p.content}</td>
                <td style={{maxWidth: 240, overflow: 'hidden', textOverflow: 'ellipsis'}}>{p.picture}</td>
                <td><button onClick={() => del(p._id)}>Delete</button></td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
}
