import { useState } from 'react';

const API = 'http://localhost:3000';

export default function Signup() {
  const [username, setU] = useState('');
  const [password, setP] = useState('');
  const [msg, setMsg] = useState('');

  async function submit(e) {
    e.preventDefault();
    try {
      const res = await fetch(`${API}/users/signup`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username, password })
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || `HTTP ${res.status}`);
      setMsg('Registered');
    } catch (e) {
      setMsg(`Error: ${e.message}`);
    }
  }

  return (
    <form onSubmit={submit}>
      <h2>Signup</h2>
      <div><input placeholder="username" value={username} onChange={e=>setU(e.target.value)} required /></div>
      <div><input type="password" placeholder="password" value={password} onChange={e=>setP(e.target.value)} required /></div>
      <button type="submit">Create account</button>
      <div style={{ marginTop: 8 }}>{msg}</div>
    </form>
  );
}
