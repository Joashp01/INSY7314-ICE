# ICE Task 2 — Routing, User Auth & Frontend Integration

## Backend Evidence
- Created routes: `/posts` (GET, POST, PATCH, DELETE) and `/users` (signup, login).
- Middleware `checkAuth.mjs` verifies JWT tokens.
- Example test outputs included in `Example_Routes_Test.json`.

## Frontend Evidence
- React app scaffold with routing.
- Components: Navbar, PostList, PostCreate, Signup, Login.
- Tested integration with backend API.
- Token authentication verified in browser developer console.

## Git Commands Used
